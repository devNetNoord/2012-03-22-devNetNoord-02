﻿// -----------------------------------------------------------------------
// <copyright file="IAanmeldenService.cs" company="">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace SP2010Demo.Workflows.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Workflow.Activities;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    
    [ExternalDataExchange] 
    public interface IAanmeldenService 
    {
        event EventHandler<ExternalDataEventArgs> Afmelden;
    }
}
