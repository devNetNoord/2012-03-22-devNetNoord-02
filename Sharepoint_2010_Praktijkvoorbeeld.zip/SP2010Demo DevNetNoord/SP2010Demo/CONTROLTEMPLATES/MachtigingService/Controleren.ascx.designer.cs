﻿namespace SP2010Demo.CONTROLTEMPLATES.MachtigingService
{
    public partial class Controleren
    {
    }
}
