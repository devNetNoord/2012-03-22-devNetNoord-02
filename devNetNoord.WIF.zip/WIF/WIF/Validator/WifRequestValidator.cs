﻿using System;
using System.Web;
using System.Web.Util;
using Microsoft.IdentityModel.Protocols.WSFederation;

namespace Microsoft.IdentityModel
{
    public class WifRequestValidator : RequestValidator
    {
        protected override bool IsValidRequestString(
            HttpContext context,
            string value,
            RequestValidationSource requestValidationSource,
            string collectionKey,
            out int validationFailureIndex)
        {
            validationFailureIndex = 0;

            // Check for passive federation in form (HTTP POST) values
            if (requestValidationSource == RequestValidationSource.Form)
            {
                // Validate if being checked is WS-Federation response 
                if (collectionKey.Equals(WSFederationConstants.Parameters.Result))
                {
                    // Try to construct a SignInResponseMessage from value
                    var message =
                        WSFederationMessage.CreateFromFormPost(context.Request)
                        as SignInResponseMessage;
                    if (message != null) return true;
                }
            }

            // Validation inconclusive, fall back on built-in method
            return base.IsValidRequestString(
                context,
                value,
                requestValidationSource,
                collectionKey,
                out validationFailureIndex);
        }
    }
}
