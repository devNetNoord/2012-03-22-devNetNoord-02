﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Linq;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.WorkflowActions;

namespace SP2010Demo.Workflows.AanmeldenWorkflow
{
    public sealed partial class AanmeldenWorkflow : StateMachineWorkflowActivity
    {
        public AanmeldenWorkflow()
        {
            InitializeComponent();
        }

        public SPWorkflowActivationProperties workflowProperties = new SPWorkflowActivationProperties();
        public static DependencyProperty TaakPropertiesProperty = DependencyProperty.Register("TaakProperties", typeof(Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties), typeof(SP2010Demo.Workflows.AanmeldenWorkflow.AanmeldenWorkflow));

        [DesignerSerializationVisibilityAttribute(DesignerSerializationVisibility.Visible)]
        [BrowsableAttribute(true)]
        [CategoryAttribute("Misc")]
        public SPWorkflowTaskProperties TaakProperties
        {
            get
            {
                return ((Microsoft.SharePoint.Workflow.SPWorkflowTaskProperties)(base.GetValue(SP2010Demo.Workflows.AanmeldenWorkflow.AanmeldenWorkflow.TaakPropertiesProperty)));
            }
            set
            {
                base.SetValue(SP2010Demo.Workflows.AanmeldenWorkflow.AanmeldenWorkflow.TaakPropertiesProperty, value);
            }
        }


        private void ZetAangemeldTaskProperties(object sender, EventArgs e)
        {
            TaakProperties = new SPWorkflowTaskProperties
            {
                AssignedTo = @"RJ-Laptop\RJ",
                Title = "Aanmelding binnengekomen",
                DueDate = DateTime.Now.AddDays(2),
                PercentComplete = 0
            };
            TaakProperties.ExtendedProperties["ControlTemplate"] = "Aangemeld";
        }
        private void ZetAfgemeldTaskProperties(object sender, EventArgs e)
        {
            TaakProperties = new SPWorkflowTaskProperties
            {
                AssignedTo = @"RJ-Laptop\RJ",
                Title = "Afmelding binnengekomen",
                DueDate = DateTime.Now.AddDays(2),
                PercentComplete = 0
            };
            TaakProperties.ExtendedProperties["ControlTemplate"] = "Afgemeld";
        }
        private void ZetControleFoutTaskProperties(object sender, EventArgs e)
        {
            TaakProperties = new SPWorkflowTaskProperties
            {
                AssignedTo = @"RJ-Laptop\RJ",
                Title = "Persoon is niet ouder dan 18",
                DueDate = DateTime.Now.AddDays(2),
                PercentComplete = 0
            };
            TaakProperties.ExtendedProperties["ControlTemplate"] = "Controleren";
        }

        private void CreateTaak(object sender, EventArgs e)
        {
            CreateTaskWithContentType task = sender as CreateTaskWithContentType;
            if (task != null)
            {
                task.TaskId = Guid.NewGuid();
                task.ContentTypeId = "0x0108010067ed61abd4994abfa427991318fe00a5";

            }

        }
    }
}
