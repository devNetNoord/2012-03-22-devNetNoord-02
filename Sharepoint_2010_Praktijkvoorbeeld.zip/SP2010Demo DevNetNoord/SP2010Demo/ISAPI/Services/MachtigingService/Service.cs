﻿// -----------------------------------------------------------------------
// <copyright file="Service.cs" company="">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace SP2010Demo.ISAPI.Services.MachtigingService
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.ServiceModel;
    using System.ServiceModel.Activation;
    using Microsoft.SharePoint.Client.Services;
    using Microsoft.SharePoint;
    using Microsoft.SharePoint.Workflow;
    using SP2010Demo.Workflows.Services;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    /// AspNetCompatibilityRequirements Required
    /// Sharepoint draait zelf al in AspNetCompatibilityMode, dus om een SPContext instance te krijgen geven we aan dat deze server daar ook
    /// onder moet draaien
    [BasicHttpBindingServiceMetadataExchangeEndpointAttribute]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Required)]
    public class Service :IService
    {

        public string Aanmelden(string naam, string email, DateTime geboorteDatum)
        {
            var list= SPContext.Current.Web.Lists["Aanmeldingen"];
            SPListItem item = list.AddItem();
            item["Title"] = Guid.NewGuid().ToString();
            item["Naam"] = naam;
            item["Email"] = email;
            item["GeboorteDatum"] = geboorteDatum;
            item.Update();
            return item.UniqueId.ToString();
        }

        public bool Afmelden(string id)
        {        
            try
            {
                SPListItem item = SPContext.Current.Web.Lists["Aanmeldingen"].GetItemById(Convert.ToInt32(id));
                SPWorkflow wf = item.Workflows[0];
                SPWorkflowExternalDataExchangeService.RaiseEvent(
                    SPContext.Current.Web,
                    wf.InstanceId,
                    typeof(IAanmeldenService),
                    "Afmelden",
                    null);
               return true;
            }
            catch(Exception ex)
            {
                return false;
            }             
        }
    }

    [ServiceContract]
    public interface IService
    {

        [OperationContract]
        string Aanmelden(string naam, string email, DateTime geboorteDatum);
        
        [OperationContract]
        bool Afmelden(string id);
    }

}
