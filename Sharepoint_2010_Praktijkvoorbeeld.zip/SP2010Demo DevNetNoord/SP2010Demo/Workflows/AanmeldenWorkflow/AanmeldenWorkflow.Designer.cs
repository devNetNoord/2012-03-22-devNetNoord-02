﻿using System;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Collections;
using System.Drawing;
using System.Reflection;
using System.Workflow.ComponentModel.Compiler;
using System.Workflow.ComponentModel.Serialization;
using System.Workflow.ComponentModel;
using System.Workflow.ComponentModel.Design;
using System.Workflow.Runtime;
using System.Workflow.Activities;
using System.Workflow.Activities.Rules;

namespace SP2010Demo.Workflows.AanmeldenWorkflow
{
    public sealed partial class AanmeldenWorkflow
    {
        #region Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        [System.Diagnostics.DebuggerNonUserCode]
        private void InitializeComponent()
        {
            this.CanModifyActivities = true;
            System.Workflow.Activities.Rules.RuleConditionReference ruleconditionreference1 = new System.Workflow.Activities.Rules.RuleConditionReference();
            System.Workflow.Runtime.CorrelationToken correlationtoken1 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind1 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Runtime.CorrelationToken correlationtoken2 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.Runtime.CorrelationToken correlationtoken3 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind2 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.Runtime.CorrelationToken correlationtoken4 = new System.Workflow.Runtime.CorrelationToken();
            System.Workflow.ComponentModel.ActivityBind activitybind3 = new System.Workflow.ComponentModel.ActivityBind();
            System.Workflow.ComponentModel.ActivityBind activitybind4 = new System.Workflow.ComponentModel.ActivityBind();
            this.setStateActivity4 = new System.Workflow.Activities.SetStateActivity();
            this.codeActivity1 = new System.Workflow.Activities.CodeActivity();
            this.setStateActivity3 = new System.Workflow.Activities.SetStateActivity();
            this.NeeNietGoed = new System.Workflow.Activities.IfElseBranchActivity();
            this.JaIsGoed = new System.Workflow.Activities.IfElseBranchActivity();
            this.createTaskWithContentType2 = new Microsoft.SharePoint.WorkflowActions.CreateTaskWithContentType();
            this.setState5 = new Microsoft.SharePoint.WorkflowActions.SetState();
            this.ControleerGeboorteDatum = new System.Workflow.Activities.IfElseActivity();
            this.setState4 = new Microsoft.SharePoint.WorkflowActions.SetState();
            this.createTaskWithContentType1 = new Microsoft.SharePoint.WorkflowActions.CreateTaskWithContentType();
            this.codeActivityZetAfgemeldTaakProperties = new System.Workflow.Activities.CodeActivity();
            this.setState3 = new Microsoft.SharePoint.WorkflowActions.SetState();
            this.logToHistoryListActivity3 = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
            this.setStateActivity2 = new System.Workflow.Activities.SetStateActivity();
            this.handleExternalEventActivity1 = new System.Workflow.Activities.HandleExternalEventActivity();
            this.createTaskAangemeld = new Microsoft.SharePoint.WorkflowActions.CreateTaskWithContentType();
            this.codeActivityZetAangemeldTaakProperties = new System.Workflow.Activities.CodeActivity();
            this.setState2 = new Microsoft.SharePoint.WorkflowActions.SetState();
            this.logToHistoryListActivity2 = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
            this.setStateActivity1 = new System.Workflow.Activities.SetStateActivity();
            this.setState1 = new Microsoft.SharePoint.WorkflowActions.SetState();
            this.logToHistoryListActivity1 = new Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity();
            this.onWorkflowActivated1 = new Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated();
            this.stateInitializationFout = new System.Workflow.Activities.StateInitializationActivity();
            this.stateInitializationControleren = new System.Workflow.Activities.StateInitializationActivity();
            this.stateInitializationAfgemeld = new System.Workflow.Activities.StateInitializationActivity();
            this.eventAfmelden = new System.Workflow.Activities.EventDrivenActivity();
            this.stateInitializationAangemeld = new System.Workflow.Activities.StateInitializationActivity();
            this.eventOnWorkflowActivated = new System.Workflow.Activities.EventDrivenActivity();
            this.Fout = new System.Workflow.Activities.StateActivity();
            this.Controleren = new System.Workflow.Activities.StateActivity();
            this.Afgemeld = new System.Workflow.Activities.StateActivity();
            this.Aangemeld = new System.Workflow.Activities.StateActivity();
            this.Einde = new System.Workflow.Activities.StateActivity();
            this.Ontvangen = new System.Workflow.Activities.StateActivity();
            // 
            // setStateActivity4
            // 
            this.setStateActivity4.Name = "setStateActivity4";
            this.setStateActivity4.TargetStateName = "Fout";
            // 
            // codeActivity1
            // 
            this.codeActivity1.Name = "codeActivity1";
            this.codeActivity1.ExecuteCode += new System.EventHandler(this.ZetControleFoutTaskProperties);
            // 
            // setStateActivity3
            // 
            this.setStateActivity3.Name = "setStateActivity3";
            this.setStateActivity3.TargetStateName = "Aangemeld";
            // 
            // NeeNietGoed
            // 
            this.NeeNietGoed.Activities.Add(this.codeActivity1);
            this.NeeNietGoed.Activities.Add(this.setStateActivity4);
            this.NeeNietGoed.Name = "NeeNietGoed";
            // 
            // JaIsGoed
            // 
            this.JaIsGoed.Activities.Add(this.setStateActivity3);
            ruleconditionreference1.ConditionName = "OuderDan18";
            this.JaIsGoed.Condition = ruleconditionreference1;
            this.JaIsGoed.Name = "JaIsGoed";
            // 
            // createTaskWithContentType2
            // 
            this.createTaskWithContentType2.ContentTypeId = "0x0108010067ed61abd4994abfa427991318fe00a5";
            correlationtoken1.Name = "CreateFoutTaakToken";
            correlationtoken1.OwnerActivityName = "Fout";
            this.createTaskWithContentType2.CorrelationToken = correlationtoken1;
            this.createTaskWithContentType2.ListItemId = -1;
            this.createTaskWithContentType2.Name = "createTaskWithContentType2";
            this.createTaskWithContentType2.SpecialPermissions = null;
            this.createTaskWithContentType2.TaskId = new System.Guid("00000000-0000-0000-0000-000000000000");
            activitybind1.Name = "AanmeldenWorkflow";
            activitybind1.Path = "TaakProperties";
            this.createTaskWithContentType2.MethodInvoking += new System.EventHandler(this.CreateTaak);
            this.createTaskWithContentType2.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTaskWithContentType.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind1)));
            // 
            // setState5
            // 
            correlationtoken2.Name = "workflowToken";
            correlationtoken2.OwnerActivityName = "AanmeldenWorkflow";
            this.setState5.CorrelationToken = correlationtoken2;
            this.setState5.Name = "setState5";
            this.setState5.State = 20;
            // 
            // ControleerGeboorteDatum
            // 
            this.ControleerGeboorteDatum.Activities.Add(this.JaIsGoed);
            this.ControleerGeboorteDatum.Activities.Add(this.NeeNietGoed);
            this.ControleerGeboorteDatum.Name = "ControleerGeboorteDatum";
            // 
            // setState4
            // 
            this.setState4.CorrelationToken = correlationtoken2;
            this.setState4.Name = "setState4";
            this.setState4.State = 19;
            // 
            // createTaskWithContentType1
            // 
            this.createTaskWithContentType1.ContentTypeId = "0x0108010067ed61abd4994abfa427991318fe00a5";
            correlationtoken3.Name = "AfgemeldTaakToken";
            correlationtoken3.OwnerActivityName = "Afgemeld";
            this.createTaskWithContentType1.CorrelationToken = correlationtoken3;
            this.createTaskWithContentType1.ListItemId = -1;
            this.createTaskWithContentType1.Name = "createTaskWithContentType1";
            this.createTaskWithContentType1.SpecialPermissions = null;
            this.createTaskWithContentType1.TaskId = new System.Guid("00000000-0000-0000-0000-000000000000");
            activitybind2.Name = "AanmeldenWorkflow";
            activitybind2.Path = "TaakProperties";
            this.createTaskWithContentType1.MethodInvoking += new System.EventHandler(this.CreateTaak);
            this.createTaskWithContentType1.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTaskWithContentType.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind2)));
            // 
            // codeActivityZetAfgemeldTaakProperties
            // 
            this.codeActivityZetAfgemeldTaakProperties.Name = "codeActivityZetAfgemeldTaakProperties";
            this.codeActivityZetAfgemeldTaakProperties.ExecuteCode += new System.EventHandler(this.ZetAfgemeldTaskProperties);
            // 
            // setState3
            // 
            this.setState3.CorrelationToken = correlationtoken2;
            this.setState3.Name = "setState3";
            this.setState3.State = 17;
            // 
            // logToHistoryListActivity3
            // 
            this.logToHistoryListActivity3.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
            this.logToHistoryListActivity3.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
            this.logToHistoryListActivity3.HistoryDescription = "Afgemeld";
            this.logToHistoryListActivity3.HistoryOutcome = "";
            this.logToHistoryListActivity3.Name = "logToHistoryListActivity3";
            this.logToHistoryListActivity3.OtherData = "";
            this.logToHistoryListActivity3.UserId = -1;
            // 
            // setStateActivity2
            // 
            this.setStateActivity2.Name = "setStateActivity2";
            this.setStateActivity2.TargetStateName = "Afgemeld";
            // 
            // handleExternalEventActivity1
            // 
            this.handleExternalEventActivity1.EventName = "Afmelden";
            this.handleExternalEventActivity1.InterfaceType = typeof(SP2010Demo.Workflows.Services.IAanmeldenService);
            this.handleExternalEventActivity1.Name = "handleExternalEventActivity1";
            // 
            // createTaskAangemeld
            // 
            this.createTaskAangemeld.ContentTypeId = "0x0108010067ed61abd4994abfa427991318fe00a5";
            correlationtoken4.Name = "AangemeldTaakToken";
            correlationtoken4.OwnerActivityName = "Aangemeld";
            this.createTaskAangemeld.CorrelationToken = correlationtoken4;
            this.createTaskAangemeld.ListItemId = -1;
            this.createTaskAangemeld.Name = "createTaskAangemeld";
            this.createTaskAangemeld.SpecialPermissions = null;
            this.createTaskAangemeld.TaskId = new System.Guid("00000000-0000-0000-0000-000000000000");
            activitybind3.Name = "AanmeldenWorkflow";
            activitybind3.Path = "TaakProperties";
            this.createTaskAangemeld.MethodInvoking += new System.EventHandler(this.CreateTaak);
            this.createTaskAangemeld.SetBinding(Microsoft.SharePoint.WorkflowActions.CreateTaskWithContentType.TaskPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind3)));
            // 
            // codeActivityZetAangemeldTaakProperties
            // 
            this.codeActivityZetAangemeldTaakProperties.Name = "codeActivityZetAangemeldTaakProperties";
            this.codeActivityZetAangemeldTaakProperties.ExecuteCode += new System.EventHandler(this.ZetAangemeldTaskProperties);
            // 
            // setState2
            // 
            this.setState2.CorrelationToken = correlationtoken2;
            this.setState2.Name = "setState2";
            this.setState2.State = 16;
            // 
            // logToHistoryListActivity2
            // 
            this.logToHistoryListActivity2.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
            this.logToHistoryListActivity2.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
            this.logToHistoryListActivity2.HistoryDescription = "Aangemeld";
            this.logToHistoryListActivity2.HistoryOutcome = "";
            this.logToHistoryListActivity2.Name = "logToHistoryListActivity2";
            this.logToHistoryListActivity2.OtherData = "";
            this.logToHistoryListActivity2.UserId = -1;
            // 
            // setStateActivity1
            // 
            this.setStateActivity1.Name = "setStateActivity1";
            this.setStateActivity1.TargetStateName = "Controleren";
            // 
            // setState1
            // 
            this.setState1.CorrelationToken = correlationtoken2;
            this.setState1.Name = "setState1";
            this.setState1.State = 15;
            // 
            // logToHistoryListActivity1
            // 
            this.logToHistoryListActivity1.Duration = System.TimeSpan.Parse("-10675199.02:48:05.4775808");
            this.logToHistoryListActivity1.EventId = Microsoft.SharePoint.Workflow.SPWorkflowHistoryEventType.WorkflowComment;
            this.logToHistoryListActivity1.HistoryDescription = "Aanmelding ontvangen";
            this.logToHistoryListActivity1.HistoryOutcome = "";
            this.logToHistoryListActivity1.Name = "logToHistoryListActivity1";
            this.logToHistoryListActivity1.OtherData = "";
            this.logToHistoryListActivity1.UserId = -1;
            // 
            // onWorkflowActivated1
            // 
            this.onWorkflowActivated1.CorrelationToken = correlationtoken2;
            this.onWorkflowActivated1.EventName = "OnWorkflowActivated";
            this.onWorkflowActivated1.Name = "onWorkflowActivated1";
            activitybind4.Name = "AanmeldenWorkflow";
            activitybind4.Path = "workflowProperties";
            this.onWorkflowActivated1.SetBinding(Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated.WorkflowPropertiesProperty, ((System.Workflow.ComponentModel.ActivityBind)(activitybind4)));
            // 
            // stateInitializationFout
            // 
            this.stateInitializationFout.Activities.Add(this.setState5);
            this.stateInitializationFout.Activities.Add(this.createTaskWithContentType2);
            this.stateInitializationFout.Name = "stateInitializationFout";
            // 
            // stateInitializationControleren
            // 
            this.stateInitializationControleren.Activities.Add(this.setState4);
            this.stateInitializationControleren.Activities.Add(this.ControleerGeboorteDatum);
            this.stateInitializationControleren.Name = "stateInitializationControleren";
            // 
            // stateInitializationAfgemeld
            // 
            this.stateInitializationAfgemeld.Activities.Add(this.logToHistoryListActivity3);
            this.stateInitializationAfgemeld.Activities.Add(this.setState3);
            this.stateInitializationAfgemeld.Activities.Add(this.codeActivityZetAfgemeldTaakProperties);
            this.stateInitializationAfgemeld.Activities.Add(this.createTaskWithContentType1);
            this.stateInitializationAfgemeld.Name = "stateInitializationAfgemeld";
            // 
            // eventAfmelden
            // 
            this.eventAfmelden.Activities.Add(this.handleExternalEventActivity1);
            this.eventAfmelden.Activities.Add(this.setStateActivity2);
            this.eventAfmelden.Name = "eventAfmelden";
            // 
            // stateInitializationAangemeld
            // 
            this.stateInitializationAangemeld.Activities.Add(this.logToHistoryListActivity2);
            this.stateInitializationAangemeld.Activities.Add(this.setState2);
            this.stateInitializationAangemeld.Activities.Add(this.codeActivityZetAangemeldTaakProperties);
            this.stateInitializationAangemeld.Activities.Add(this.createTaskAangemeld);
            this.stateInitializationAangemeld.Name = "stateInitializationAangemeld";
            // 
            // eventOnWorkflowActivated
            // 
            this.eventOnWorkflowActivated.Activities.Add(this.onWorkflowActivated1);
            this.eventOnWorkflowActivated.Activities.Add(this.logToHistoryListActivity1);
            this.eventOnWorkflowActivated.Activities.Add(this.setState1);
            this.eventOnWorkflowActivated.Activities.Add(this.setStateActivity1);
            this.eventOnWorkflowActivated.Name = "eventOnWorkflowActivated";
            // 
            // Fout
            // 
            this.Fout.Activities.Add(this.stateInitializationFout);
            this.Fout.Name = "Fout";
            // 
            // Controleren
            // 
            this.Controleren.Activities.Add(this.stateInitializationControleren);
            this.Controleren.Name = "Controleren";
            // 
            // Afgemeld
            // 
            this.Afgemeld.Activities.Add(this.stateInitializationAfgemeld);
            this.Afgemeld.Name = "Afgemeld";
            // 
            // Aangemeld
            // 
            this.Aangemeld.Activities.Add(this.stateInitializationAangemeld);
            this.Aangemeld.Activities.Add(this.eventAfmelden);
            this.Aangemeld.Name = "Aangemeld";
            // 
            // Einde
            // 
            this.Einde.Name = "Einde";
            // 
            // Ontvangen
            // 
            this.Ontvangen.Activities.Add(this.eventOnWorkflowActivated);
            this.Ontvangen.Name = "Ontvangen";
            // 
            // AanmeldenWorkflow
            // 
            this.Activities.Add(this.Ontvangen);
            this.Activities.Add(this.Einde);
            this.Activities.Add(this.Aangemeld);
            this.Activities.Add(this.Afgemeld);
            this.Activities.Add(this.Controleren);
            this.Activities.Add(this.Fout);
            this.CompletedStateName = "Einde";
            this.DynamicUpdateCondition = null;
            this.InitialStateName = "Ontvangen";
            this.Name = "AanmeldenWorkflow";
            this.CanModifyActivities = false;

        }

        #endregion

        private Microsoft.SharePoint.WorkflowActions.SetState setState4;

        private Microsoft.SharePoint.WorkflowActions.SetState setState5;

        private Microsoft.SharePoint.WorkflowActions.CreateTaskWithContentType createTaskWithContentType1;

        private CodeActivity codeActivityZetAfgemeldTaakProperties;

        private Microsoft.SharePoint.WorkflowActions.CreateTaskWithContentType createTaskWithContentType2;

        private CodeActivity codeActivity1;

        private CodeActivity codeActivityZetAangemeldTaakProperties;

        private StateInitializationActivity stateInitializationFout;

        private StateActivity Einde;

        private SetStateActivity setStateActivity1;

        private StateActivity Afgemeld;

        private StateActivity Aangemeld;

        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logToHistoryListActivity2;

        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logToHistoryListActivity1;

        private StateInitializationActivity stateInitializationAangemeld;

        private Microsoft.SharePoint.WorkflowActions.SetState setState1;

        private Microsoft.SharePoint.WorkflowActions.SetState setState2;

        private EventDrivenActivity eventAfmelden;

        private HandleExternalEventActivity handleExternalEventActivity1;

        private SetStateActivity setStateActivity2;

        private StateInitializationActivity stateInitializationAfgemeld;

        private Microsoft.SharePoint.WorkflowActions.SetState setState3;

        private Microsoft.SharePoint.WorkflowActions.LogToHistoryListActivity logToHistoryListActivity3;

        private StateActivity Fout;

        private StateActivity Controleren;

        private IfElseBranchActivity NeeNietGoed;

        private IfElseBranchActivity JaIsGoed;

        private IfElseActivity ControleerGeboorteDatum;

        private StateInitializationActivity stateInitializationControleren;

        private SetStateActivity setStateActivity3;

        private SetStateActivity setStateActivity4;

        private Microsoft.SharePoint.WorkflowActions.CreateTaskWithContentType createTaskAangemeld;

        private Microsoft.SharePoint.WorkflowActions.OnWorkflowActivated onWorkflowActivated1;

        private EventDrivenActivity eventOnWorkflowActivated;

        private StateActivity Ontvangen;









































    }
}
