﻿// -----------------------------------------------------------------------
// <copyright file="AanmeldenService.cs" company="">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace SP2010Demo.Workflows.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Microsoft.SharePoint.Workflow;
using System.Workflow.Activities;

    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class AanmeldenService : SPWorkflowExternalDataExchangeService, IAanmeldenService
    {
        public event EventHandler<ExternalDataEventArgs> Afmelden;

        public override void CallEventHandler(Type eventType, string eventName, object[] eventData, 
            SPWorkflow workflow, string identity, System.Workflow.Runtime.IPendingWork workHandler, object workItem)
        {
            switch (eventName)
            {
                case "Afmelden":
                    Afmelden(
                        null, 
                        new ExternalDataEventArgs(
                            workflow.InstanceId,
                            workHandler,
                            workItem)
                            );
                    break;
            }
        }

        public override void CreateSubscription(MessageEventSubscription subscription)
        {
            throw new NotImplementedException();
        }

        public override void DeleteSubscription(Guid subscriptionId)
        {
            throw new NotImplementedException();
        }
    }
}
