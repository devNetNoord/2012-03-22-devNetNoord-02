﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using SP2010Demo.Layouts.MachtigingService;

namespace SP2010Demo.CONTROLTEMPLATES.MachtigingService
{
    public partial class Controleren : UserControl
    {
        GeneriekeTaak page;
        protected void Page_Load(object sender, EventArgs e)
        {
            page = this.Page as GeneriekeTaak;

            string naam = page.SourceItem["Naam"] as string;
            string email = page.SourceItem["Email"] as string;
            Controls.Add(new LiteralControl(string.Format(@"Aanmelding binnengekomen van {0}, {1}, maar persoon is niet ouder dan 18!", naam, email)));
        }
    }
}
