﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Utilities;

namespace SP2010Demo.Layouts.MachtigingService
{
    public partial class GeneriekeTaak : LayoutsPageBase
    {
        private SPList taskList;
        private SPList sourceList;
        private SPListItem taskItem;
        private SPListItem sourceItem;

        public SPListItem TaskItem
        {
            get { return taskItem; }
        }

        public SPListItem SourceItem
        {
            get { return sourceItem; }
        }

        protected override void CreateChildControls()
        {
            taskList = SPContext.Current.List;
            taskItem = SPContext.Current.ListItem;
            sourceList = taskList.ParentWeb.Lists.GetList(new Guid(taskItem[SPBuiltInFieldId.WorkflowListId].ToString()),true);
            sourceItem = sourceList.GetItemById(Convert.ToInt32(taskItem[SPBuiltInFieldId.WorkflowItemId]));
            Control control;
            try
            {
                string path = string.Empty;
                if (BepaalAscx(out path))
                {
                    control = Page.LoadControl(path);
                    PlaceHolderControls.Controls.Add(control);
                }
            }
            catch
            { 
                control = new LiteralControl("Kan ascx niet bepalen.");
                PlaceHolderControls.Controls.Add(control);
            }

            Button sluitenButton = new Button()
            {
                Text = "Sluiten"
            };
            sluitenButton.Click +=new EventHandler(sluitenButton_Click);
            PlaceHolderControls.Controls.Add(sluitenButton);
            base.CreateChildControls();
        }

        void sluitenButton_Click(object sender, EventArgs e)
        {
            CompleteTask();
            if ((SPContext.Current != null) && SPContext.Current.IsPopUI)
            {
                Context.Response.Write(string.Format("<script type='text/javascript'>window.frameElement.commitPopup(\"{0}\");</script>",string.Empty));
                Context.Response.Flush();
                Context.Response.End();
            }
            else
            {
                string str = Page.Request.QueryString["Source"];
                if (!string.IsNullOrEmpty(str))
                {
                    SPUtility.Redirect(string.Empty, SPRedirectFlags.UseSource, Context);
                }
            }
        }

        private void CompleteTask()
        {
            taskItem[SPBuiltInFieldId.TaskStatus] = "Voltooid";
            taskItem[SPBuiltInFieldId.PercentComplete] = 1;
            taskItem[SPBuiltInFieldId.Modified] = DateTime.Now;
            taskItem.Update();
        }

        private bool BepaalAscx( out string path)
        {
            path = string.Empty;
            string controlTemplate = string.Empty;
            try
            {
                controlTemplate = taskItem["ControlTemplate"] as string;
            }
            catch
            {
                return false;
            }
            path = string.Format(@"~/_CONTROLTEMPLATES/MachtigingService/{0}.ascx",controlTemplate);
            return true;
        }
    }
}